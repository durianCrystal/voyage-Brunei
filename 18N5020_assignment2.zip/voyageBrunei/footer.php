<br><br><br><br><br>
<footer id="bottom" role="contentinfo">
			<div class="container">
                <div class="row">
				<div class="box" id="col1">
					<div class="widget">
						<h3>About Us</h3>
                        <ul class="contact">
                        <li>We are a group of people in Brunei dedicated to help locals to explore the world and tourists to have a trip with more fun and depth. Therefore, we establish the Brunei Darussalam Online Tour and Travels Management System, called VoyageBrunei. We are here to bring the world closer to Brunei and bring Brunei to the world.</li>
                        </ul>
					</div>
				</div>

				<div class="box" id="col2">
					<div class="widget">
						<h3>Destination</h3>
						<ul class="bottom-links">
							<li><a href="item_1.php">Brunei Domestic</a></li>
							<li><a href="item_2.php">Malaysia</a></li>
							<li><a href="item_3.php">China</a></li>
						</ul>
					</div>
				</div>

				<div class="box" id="col3">
					<div class="widget">
						<h3>Get In Touch</h3>
						<ul class="contact">
							<li>Tel: +1 234 567 890</li>
							<li>Email: info@voyage.com</li>
							<li>Address: Brunei</li>
						</ul>
					</div>
				</div>
            </div>
            <br>
			<div class="row copyright">
				<div>
					<p class="pull-left">
						<small class="block">&copy; 2018 VoyageBrunei. All Rights Reserved.</small> 
						<small class="block">Designed by Crystal Lee</small>
					</p>
					
				</div>
			</div>
            </div>

	</footer>