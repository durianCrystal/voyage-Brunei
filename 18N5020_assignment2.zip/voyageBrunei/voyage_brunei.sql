-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2018-11-04 20:09:52
-- 服务器版本： 10.1.36-MariaDB
-- PHP 版本： 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 数据库： `voyage_brunei`
--

-- --------------------------------------------------------

--
-- 表的结构 `admin`
--

CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(20) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `admin`
--

INSERT INTO `admin` (`admin_id`, `admin_name`, `admin_password`, `create_time`) VALUES
(2, 'admin', '827ccb0eea8a706c4c34a16891f84e7b', '2018-11-01 17:55:58');

-- --------------------------------------------------------

--
-- 表的结构 `admin_inbox`
--

CREATE TABLE `admin_inbox` (
  `m_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `sent_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `admin_inbox`
--

INSERT INTO `admin_inbox` (`m_id`, `user_id`, `message`, `sent_time`, `is_read`) VALUES
(1, 4, 'test message from user', '2018-11-03 18:56:45', 1),
(2, 4, 'test message from user (2)', '2018-11-03 18:57:10', 1),
(15, 4, 'another message', '2018-11-04 04:31:44', 1),
(32, 4, 'hi', '2018-11-04 05:36:22', 0);

-- --------------------------------------------------------

--
-- 表的结构 `guides`
--

CREATE TABLE `guides` (
  `guide_id` int(11) NOT NULL,
  `guide_name` varchar(50) NOT NULL,
  `gender` char(1) NOT NULL,
  `tel_num` varchar(20) NOT NULL,
  `work_loc` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `guides`
--

INSERT INTO `guides` (`guide_id`, `guide_name`, `gender`, `tel_num`, `work_loc`) VALUES
(1, 'Micheal Zhang', 'M', '+673-7852314', 'Brunei'),
(2, 'Vincent Liu', 'M', '+673-8565147', 'Brunei'),
(3, 'Racheal Stone', 'M', '+673-8465732', 'Brunei'),
(4, 'Helen Yu', 'M', '+673-7456258', 'Brunei'),
(5, 'Li Ting', 'M', '+86-13746885132', 'China'),
(6, 'Wu Qingyi', 'F', '+86-1586215322', 'China'),
(7, 'Mira', 'M', '+60-45678985', 'Malaysia'),
(8, 'Haziq', 'M', '+60-7895216', 'Malaysia');

-- --------------------------------------------------------

--
-- 表的结构 `guide_booked`
--

CREATE TABLE `guide_booked` (
  `guide_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_time` date NOT NULL,
  `end_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `guide_booked`
--

INSERT INTO `guide_booked` (`guide_id`, `order_id`, `user_id`, `start_time`, `end_time`) VALUES
(3, 8, 6, '2018-12-02', '2018-12-02'),
(1, 10, 4, '2018-11-27', '2018-11-27');

-- --------------------------------------------------------

--
-- 表的结构 `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `country` varchar(50) NOT NULL,
  `price` decimal(15,2) DEFAULT NULL,
  `gen_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `items`
--

INSERT INTO `items` (`item_id`, `item_name`, `country`, `price`, `gen_time`) VALUES
(1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', 'Brunei', '50.00', '2018-10-28 02:06:02'),
(2, 'Brunei Foodie Trip - Homemade food | Street Food | Fine Restaurant', 'Brunei', '50.00', '2018-10-28 02:08:53'),
(3, 'Brunei Hiking Trip - Forest | Temburong | Nature', 'Brunei', '40.00', '2018-10-28 02:12:57'),
(4, 'Kuala Lumpur Day Trip - Badu Cave | Shopping | Malay Food', 'Malaysia', '60.00', '2018-10-29 03:30:22'),
(5, 'Guangzhou Day Trip - Pearl River | Art Villiage | Temple', 'China', '70.00', '2018-10-29 03:36:04');

-- --------------------------------------------------------

--
-- 表的结构 `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(100) NOT NULL,
  `v_id` varchar(11) DEFAULT NULL,
  `guide_id` int(11) DEFAULT NULL,
  `ppl_num` int(3) NOT NULL,
  `start_time` date NOT NULL,
  `end_time` date NOT NULL,
  `total` decimal(15,2) NOT NULL,
  `tel_num` varchar(20) NOT NULL,
  `discount` decimal(15,2) DEFAULT NULL,
  `operator_id` int(11) DEFAULT NULL,
  `submit_time` datetime NOT NULL,
  `update_time` datetime NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'SUBMITTED'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `item_id`, `item_name`, `v_id`, `guide_id`, `ppl_num`, `start_time`, `end_time`, `total`, `tel_num`, `discount`, `operator_id`, `submit_time`, `update_time`, `status`) VALUES
(1, 4, 1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', 'C001', 1, 2, '2018-11-01', '2018-11-01', '100.00', '+86-13725388566', '0.00', 2, '2018-10-31 15:48:07', '2018-11-02 21:02:12', 'DONE'),
(2, 4, 4, 'Kuala Lumpur Day Trip - Badu Cave | Shopping | Malay Food', 'C003', 7, 4, '2019-01-19', '2019-01-19', '240.00', '+86-13725388566', '0.00', 2, '2018-10-31 19:11:07', '2018-11-03 17:41:52', 'CANCELLED'),
(3, 4, 5, 'Guangzhou Day Trip - Pearl River | Art Villiage | Temple', 'C004', 5, 2, '2019-01-08', '2019-01-08', '140.00', '+86-13725388566', '0.00', 2, '2018-10-31 19:11:30', '2018-11-04 10:47:26', 'CANCELLED'),
(4, 4, 1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', NULL, NULL, 6, '2018-11-30', '2018-11-30', '300.00', '+86-13725388566', '0.00', 2, '2018-10-31 19:11:52', '2018-11-02 22:17:21', 'CANCELLED'),
(5, 4, 4, 'Kuala Lumpur Day Trip - Badu Cave | Shopping | Malay Food', NULL, NULL, 3, '2019-02-22', '2019-02-22', '180.00', '+86-13725388566', '0.00', 2, '2018-10-31 19:12:11', '2018-11-02 22:30:44', 'CANCELLED'),
(6, 4, 5, 'Guangzhou Day Trip - Pearl River | Art Villiage | Temple', NULL, NULL, 4, '2019-04-26', '2019-04-26', '280.00', '+86-13725388566', '0.00', 2, '2018-10-31 19:12:27', '2018-11-02 22:31:45', 'CANCELLED'),
(7, 4, 5, 'Guangzhou Day Trip - Pearl River | Art Villiage | Temple', 'V004', 5, 5, '2018-12-01', '2018-12-01', '350.00', '+86-13725388566', '0.00', 2, '2018-10-31 20:32:56', '2018-11-04 11:08:28', 'CANCELLED'),
(8, 6, 1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', 'C001', 3, 2, '2018-12-02', '2018-12-02', '100.00', '+86-13725388566', '0.00', 2, '2018-10-31 21:03:52', '2018-11-04 11:07:06', 'CONFIRMED'),
(9, 4, 1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', NULL, NULL, 2, '2018-11-30', '2018-11-30', '100.00', '+86-13725388566', NULL, NULL, '2018-11-04 15:32:18', '2018-11-04 15:32:18', 'SUBMITTED'),
(10, 4, 1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', 'C001', 1, 2, '2018-11-27', '2018-11-27', '100.00', '+86-13725388566', '0.00', 2, '2018-11-04 18:03:04', '2018-11-04 18:05:06', 'CONFIRMED'),
(11, 4, 1, 'Brunei Cultural Trip - Water Village | Night Market | Royal Family', NULL, NULL, 3, '2018-11-27', '2018-11-27', '150.00', '+86-13725388566', NULL, NULL, '2018-11-04 18:03:16', '2018-11-04 18:03:16', 'SUBMITTED');

--
-- 触发器 `orders`
--
DELIMITER $$
CREATE TRIGGER `booked_update` AFTER UPDATE ON `orders` FOR EACH ROW BEGIN
         IF NEW.v_id IS NOT NULL AND NEW.status = 'CONFIRMED' THEN
           INSERT INTO vehicle_booked (v_id, order_id, user_id, start_time, end_time) VALUES (NEW.v_id, NEW.order_id, NEW.user_id, NEW.start_time, NEW.end_time);
         END IF;
         IF NEW.guide_id IS NOT NULL AND NEW.status = 'CONFIRMED' THEN
           INSERT INTO guide_booked (guide_id, order_id, user_id, start_time, end_time) VALUES (NEW.guide_id, NEW.order_id, NEW.user_id, NEW.start_time, NEW.end_time);
         END IF;
         
         IF NEW.status = 'CANCELLED' THEN
           DELETE FROM guide_booked WHERE order_id = NEW.order_id LIMIT 1;
         END IF;
         IF NEW.status = 'CANCELLED' THEN
           DELETE FROM vehicle_booked WHERE order_id = NEW.order_id LIMIT 1;
         END IF;
         
         
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- 表的结构 `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `user_name` varchar(20) NOT NULL,
  `user_password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `b_date` date DEFAULT NULL,
  `country` varchar(50) NOT NULL,
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `profile_pic` varchar(200) NOT NULL DEFAULT 'images/default_profile.jpg' COMMENT 'image path'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `user_password`, `email`, `b_date`, `country`, `create_time`, `profile_pic`) VALUES
(4, 'crystal', '76bb1835a2dc211ed8272b3adc2b33d1', 'duriancrystal@gmail.com', '2014-08-27', 'China', '2018-10-27 15:13:19', 'images/default_profile.jpg'),
(5, 'Zero', '098f6bcd4621d373cade4e832627b4f6', 'test@gmail.com', '2018-10-24', 'Brunei', '2018-10-30 11:35:58', 'images/default_profile.jpg'),
(6, 'durian', 'e10adc3949ba59abbe56e057f20f883e', 'crystalchreey@163.com', '2018-10-04', 'China', '2018-10-31 15:43:13', 'images/default_profile.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `user_inbox`
--

CREATE TABLE `user_inbox` (
  `m_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` varchar(500) NOT NULL,
  `sent_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `is_read` int(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `user_inbox`
--

INSERT INTO `user_inbox` (`m_id`, `user_id`, `message`, `sent_time`, `is_read`) VALUES
(18, 4, 'test', '2018-11-04 02:00:21', 1),
(19, 4, 'test', '2018-11-04 04:46:08', 1),
(20, 4, 'hello', '2018-11-04 04:46:22', 1),
(21, 4, 'hi', '2018-11-04 04:46:33', 1),
(22, 4, 'test reply', '2018-11-04 05:37:07', 0),
(23, 4, 'test reply 2', '2018-11-04 05:37:47', 0);

-- --------------------------------------------------------

--
-- 表的结构 `vehicles`
--

CREATE TABLE `vehicles` (
  `v_id` varchar(11) NOT NULL,
  `v_name` varchar(50) NOT NULL,
  `car_num` varchar(20) NOT NULL,
  `work_loc` varchar(50) NOT NULL,
  `max_size` int(3) NOT NULL,
  `min_size` int(3) NOT NULL,
  `type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `vehicles`
--

INSERT INTO `vehicles` (`v_id`, `v_name`, `car_num`, `work_loc`, `max_size`, `min_size`, `type`) VALUES
('B001', '15-seat minibus', 'BAS145', 'Brunei', 15, 8, 'bus'),
('B002', '20-seat group travel bus', 'BAE785', 'Brunei', 20, 15, 'bus'),
('B003', 'Group-trip-essential 20-seat bus', 'SK1554B', 'Malaysia', 20, 8, 'bus'),
('B004', '20-seat group-travel minibus', '89W5Q', 'China', 20, 8, 'bus'),
('C001', '4-seat comfy Nessan', 'BAS1234', 'Brunei', 4, 1, 'car'),
('C002', '4-seat cozy Honda', 'BAE4567', 'Brunei', 4, 1, 'car'),
('C003', 'comfy 4-seat Toyota', 'MDC3019', 'Malaysia', 4, 1, 'car'),
('C004', 'tidy and neat 4-seat Toyota', 'E5412', 'China', 4, 1, 'car'),
('V001', '7-seat spacious van', 'BAA4770', 'Brunei', 7, 5, 'van'),
('V002', '7-seat cozy Toyota van', 'BS1120', 'Brunei', 7, 5, 'van'),
('V003', '7-seat spacious Honada van', 'BPR9357', 'Malaysia', 7, 5, 'van'),
('V004', '7-seat comfy family van', 'Q56CD', 'China', 7, 5, 'van');

-- --------------------------------------------------------

--
-- 表的结构 `vehicle_booked`
--

CREATE TABLE `vehicle_booked` (
  `v_id` varchar(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_time` date NOT NULL,
  `end_time` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- 转存表中的数据 `vehicle_booked`
--

INSERT INTO `vehicle_booked` (`v_id`, `order_id`, `user_id`, `start_time`, `end_time`) VALUES
('C001', 8, 6, '2018-12-02', '2018-12-02'),
('C001', 10, 4, '2018-11-27', '2018-11-27');

--
-- 转储表的索引
--

--
-- 表的索引 `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `admin_name` (`admin_name`);

--
-- 表的索引 `admin_inbox`
--
ALTER TABLE `admin_inbox`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `is_read` (`is_read`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `guides`
--
ALTER TABLE `guides`
  ADD PRIMARY KEY (`guide_id`);

--
-- 表的索引 `guide_booked`
--
ALTER TABLE `guide_booked`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `guide_booked_ibfk_2` (`guide_id`),
  ADD KEY `guide_booked_ibfk_3` (`user_id`),
  ADD KEY `guide_booked_ibfk_4` (`start_time`),
  ADD KEY `guide_booked_ibfk_5` (`end_time`);

--
-- 表的索引 `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`),
  ADD UNIQUE KEY `item_name` (`item_name`),
  ADD KEY `country` (`country`),
  ADD KEY `price` (`price`);

--
-- 表的索引 `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `item_id` (`item_id`),
  ADD KEY `v_id` (`v_id`),
  ADD KEY `guide_id` (`guide_id`),
  ADD KEY `operator_id` (`operator_id`),
  ADD KEY `item_name` (`item_name`),
  ADD KEY `start_time` (`start_time`),
  ADD KEY `end_time` (`end_time`);

--
-- 表的索引 `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `user_name` (`user_name`);

--
-- 表的索引 `user_inbox`
--
ALTER TABLE `user_inbox`
  ADD PRIMARY KEY (`m_id`),
  ADD KEY `is_read` (`is_read`),
  ADD KEY `user_id` (`user_id`);

--
-- 表的索引 `vehicles`
--
ALTER TABLE `vehicles`
  ADD PRIMARY KEY (`v_id`),
  ADD KEY `max_size` (`max_size`),
  ADD KEY `type` (`type`),
  ADD KEY `work_loc` (`work_loc`),
  ADD KEY `min_size` (`min_size`);

--
-- 表的索引 `vehicle_booked`
--
ALTER TABLE `vehicle_booked`
  ADD PRIMARY KEY (`order_id`),
  ADD KEY `vehicle_booked_ibfk_2` (`user_id`),
  ADD KEY `vehicle_booked_ibfk_4` (`start_time`),
  ADD KEY `vehicle_booked_ibfk_5` (`end_time`),
  ADD KEY `vehicle_booked_ibfk_6` (`v_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `admin`
--
ALTER TABLE `admin`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- 使用表AUTO_INCREMENT `admin_inbox`
--
ALTER TABLE `admin_inbox`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- 使用表AUTO_INCREMENT `guides`
--
ALTER TABLE `guides`
  MODIFY `guide_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- 使用表AUTO_INCREMENT `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- 使用表AUTO_INCREMENT `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- 使用表AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- 使用表AUTO_INCREMENT `user_inbox`
--
ALTER TABLE `user_inbox`
  MODIFY `m_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- 限制导出的表
--

--
-- 限制表 `admin_inbox`
--
ALTER TABLE `admin_inbox`
  ADD CONSTRAINT `admin_inbox_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `guide_booked`
--
ALTER TABLE `guide_booked`
  ADD CONSTRAINT `guide_booked_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guide_booked_ibfk_2` FOREIGN KEY (`guide_id`) REFERENCES `orders` (`guide_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guide_booked_ibfk_3` FOREIGN KEY (`user_id`) REFERENCES `orders` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guide_booked_ibfk_4` FOREIGN KEY (`start_time`) REFERENCES `orders` (`start_time`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `guide_booked_ibfk_5` FOREIGN KEY (`end_time`) REFERENCES `orders` (`end_time`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `items` (`item_id`),
  ADD CONSTRAINT `orders_ibfk_3` FOREIGN KEY (`guide_id`) REFERENCES `guides` (`guide_id`),
  ADD CONSTRAINT `orders_ibfk_5` FOREIGN KEY (`item_name`) REFERENCES `items` (`item_name`),
  ADD CONSTRAINT `orders_ibfk_6` FOREIGN KEY (`operator_id`) REFERENCES `admin` (`admin_id`),
  ADD CONSTRAINT `orders_ibfk_7` FOREIGN KEY (`v_id`) REFERENCES `vehicles` (`v_id`),
  ADD CONSTRAINT `orders_ibfk_8` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);

--
-- 限制表 `user_inbox`
--
ALTER TABLE `user_inbox`
  ADD CONSTRAINT `user_inbox_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- 限制表 `vehicle_booked`
--
ALTER TABLE `vehicle_booked`
  ADD CONSTRAINT `vehicle_booked_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `orders` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehicle_booked_ibfk_3` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehicle_booked_ibfk_4` FOREIGN KEY (`start_time`) REFERENCES `orders` (`start_time`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehicle_booked_ibfk_5` FOREIGN KEY (`end_time`) REFERENCES `orders` (`end_time`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `vehicle_booked_ibfk_6` FOREIGN KEY (`v_id`) REFERENCES `orders` (`v_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
