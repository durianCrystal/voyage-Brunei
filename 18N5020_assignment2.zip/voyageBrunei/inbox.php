<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>
    <link rel="stylesheet" href="css/account.css"/>
    <link rel="stylesheet" href="css/orderTabs.css"/>
    <link rel="stylesheet" href="css/more.css"/>

</head>
    
<body >
    
    <?php include("navBar.php"); ?>

    <?php 
        require('db.php');
        $user_name = $_SESSION['user_name'];
        $query = "SELECT * FROM users WHERE user_name = '$user_name'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            $profile_pic = $row['profile_pic'];
            $email = $row['email'];
            $b_date = $row['b_date'];
            $create_time = $row['create_time'];
            $_SESSION['profile_pic'] = $profile_pic;
            $_SESSION['email'] = $email;
            $_SESSION['b_date'] = $b_date;
            $_SESSION['create_time'] = $create_time;
        }else{
            echo "<h2>Profile pic can't find</h2>";
        }
        
        ?>
    <div id="bg"></div>
    <section id="body">
        <aside id="sidebar" class="column-left">
			
            
            <div id="profilePic">
                <img src="<?php echo $_SESSION['profile_pic']; ?>" > <br>
            </div>
            <div id="username">
                <p><?php echo $_SESSION['user_name']; ?></p>
            </div>
			
            <div id="tabs">
                <div class="tab" id="profile">
                    <a href=account.php> <h3>Profile</h3></a>
                </div>
                <div class="tab" id="myOrder">
                    <a href=myOrder.php><h3>My Order</h3></a>
                </div>
                <div class="tab" id="inbox">
                    <h3 style=" background: lightblue; color: white;">Inbox</h3>
                </div>
            </div>
			
			


						
        </aside>
        
       
        
        <section id="content" class="column-right">
            <div class="row" id="tab_title">
                <h1>Inbox</h1>
            </div>
            
            
            
            <div class="hidden_more" id="hidden_more" style="display:none">
                        <h3>Contact Us</h3>
                        
                        <form action="" method="POST">
                            
                            <div class="customer_reply input-group">
                                <textarea id="message" class="text" cols="65" rows ="20" name="user_message" required></textarea>
                            </div>
                            <div class="detail_row input-group">
                                <input type="submit" name="submit" value="Submit" />
                                <button onclick="hidediv()">Exit</button>
                            </div>
                        </form>
                        
                        <?php
                            //pass the message to admin inbox
                            if(isset($_POST['user_message'])){
                                $user_id = $_SESSION['user_id'];
                                $user_message = $_POST['user_message'];
                                
                                
                                $query_user = "INSERT INTO admin_inbox (user_id, message)
                                    VALUES('$user_id', '$user_message')";
                                $result_user_message = mysqli_query($con, $query_user);
                                $post = array_filter($_POST);
                                /*
                                if($result_user_message){
                                    echo "<div style='width:100%'>Message is sent successfully!<div>";
                                }*/
                                unset($_POST['user_message']);
                            }
                        ?>
                        
            </div>
            
            <div id="row_contact">
                <button id="contact" onclick="showdiv()">Contact us</button>
            </div>
            
            <div id="inbox_panel" style="margin-top:70px">
                
             <?php
            //to display messages in pages
            $page = @$_GET["page"];
            if($page == "" || $page == "1"){
                $page1=0;
            } 
            else{
                $page1 = ($page*3)-3;
            }
            $user_id = $_SESSION['user_id'];
            $query_message = mysqli_query($con, "SELECT * FROM user_inbox WHERE user_id = '$user_id' ORDER BY is_read ASC, sent_time DESC limit $page1, 3");
            $i = 0;
            while($row=mysqli_fetch_array($query_message)){
                //display order infomation
                $m_id = $row['m_id'];
                //to make the unread message blue
                if($row['is_read']==1){
                        $style = "background-color: rgba(94, 93, 82, 0.1)";
                    }else{
                        $style = "background-color:aliceblue";
                    }
                
                ?>
                
                <div class='orderTab' style="<?php echo $style; ?>; height:110px;" >
                    <input type="hidden" id="m_id_update" name="m_id_update_<?php echo $i;?>" value="<?php echo $m_id;?>"/>
                    <div class='header' style="float:right">
                        <div class="col1">
                        
                        </div>
                        <div class="col2">
                            <p><?php echo $row['sent_time'];?> </p>
                        </div>
                        
                    </div>
                    <div class="tabDetails">
                        
                        <p><?php echo $row['message'];?></p>
                        
                    </div>
                    <div class="tab_bottom">
                        <form action="" method="POST">
                            <input type="submit" name="read<?php echo $m_id; ?>" value="read" id="read_btn">
                        </form>
                        
                    </div>
                    <?php
                        //if read button is clicked then is_read value of this row will be 1
                        $btn_name = 'read'.(string)$m_id;
                        if(isset($_POST[$btn_name])){
                            $user_id = $_SESSION['user_id'];
                            $update_read = mysqli_query($con, "
                            UPDATE user_inbox
                            SET is_read = 1
                            WHERE user_id = '$user_id' AND m_id = '$m_id'
                            ");
                            echo "<script>document.getElementsByClassName('orderTab')[$i].style.background= 'rgba(94, 93, 82, 0.1)'</script>";
                        }
                    
                    ?>
                </div>

                
                <?php
                $i = $i + 1;
            }
        
            //to count the number of pages
            $query_all_message = mysqli_query($con, "SELECT * FROM user_inbox WHERE user_id = '$user_id'");
            $count = mysqli_num_rows($query_all_message);
            $a = $count / 3;
            $a = ceil($a);
            
            if($page == "" || $page == "1"){
                $b = 1;
                $next = $b + 1;
                if($count > 3){
                ?>
                
                    <a href="inbox.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                
                 <?php }
            }
            else if($page == $a){
                $b = $page;
                $previous = $b - 1;
                ?>
                
                <a href="inbox.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a> <?php
            }
            else{
                $b = $page;
                $previous = $b - 1;
                $next = $b + 1;
                ?>
                
                 
                <a href="inbox.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                <a href="inbox.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a>
            
            <?php
            }
            /*for($b = 1; $b <= $a; $b++){
                ?>
                <a href="myOrder.php?page=<?php echo $b;?>"><?php echo $b; ?></a> <?php
            }*/
        ?>
            
            </div>
		</section>


	</section>
    
    <script>
        
        function expand_details(this_row){
            showdiv(this_row)
        }
        function showdiv() {            
            document.getElementById("bg").style.display ="block";
            document.getElementsByClassName("hidden_more")[0].style.display ="block";
        }
        function hidediv() {
            document.getElementById("bg").style.display ='none';
            document.getElementsByClassName("hidden_more")[0].style.display ='none';
        }
    </script>
    
    <style>
        .round a {
            text-decoration: none;
            display: inline-block;
            #padding: 8px 16px;
        }

        .round a:hover {
            background-color: #ddd;
            color: black;
        }

        .previous {
            background-color: #f1f1f1;
            color: black;
        }

        .next {
            background-color: #55d6aa;
            color: white;
        }

        .round {
            #border-radius: 50%;
            padding: 10px 15px;
            float: right;
            margin-top: 10px;
        }
        
        .hidden_more{
            height: 70%;
            text-align: center;
        }
        
        .hidden_more .input-group{
            text-align: center;
            display: inline-block;
        }
        
        .hidden_more input[type='submit']{
            width: 100px;
        }
        .hidden_more button{
            width: 100px;
        }
        
        #contact{
            border: 0px;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            -ms-border-radius: 4px;
            border-radius: 4px;
            -webkit-transition: 0.5s;
            -o-transition: 0.5s;
            transition: 0.5s;
            padding: 5px 10px;
            width: 100px;
            margin-right: 19px;
        }
        
        #contact:hover{
            opacity: 1;
            visibility: visible;
            bottom: 0px;
            #border: 2px solid #0adec0 !important;
            background: #0adec0 !important;
        }
        
        #row_contact{
            float: right;
            margin-bottom: 15px;
        }
        .tab_bottom{
            float: right;
            display: flex;
            
        }
        .tab_bottom input[type='submit']{
            border: 0px;
            -webkit-border-radius: 4px;
            -moz-border-radius: 4px;
            -ms-border-radius: 4px;
            border-radius: 4px;
            -webkit-transition: 0.5s;
            -o-transition: 0.5s;
            transition: 0.5s;
            padding: 5px 10px;
            margin-top: 0;
            width: 100px;
        }
    </style>
    

       

    
	<?php include("footer.php"); ?>

</body>
</html>