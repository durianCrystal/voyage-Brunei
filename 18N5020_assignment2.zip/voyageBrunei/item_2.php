<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>

</head>
    
<body >
    
    <?php include('navBar.php'); ?>

    <?php 
        require('db.php');
        $this_item = 4;
        $query = "SELECT * FROM items WHERE item_id = '$this_item'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        $row = mysqli_fetch_assoc($result);
        if($rows!=1){
            echo "
            <div class='header'>
            <h2>Oops!</h2>
            </div>
            <div class='form'>
            <h3>This item doesn't exist.</h3>";
        }else{
            $item_id = $row['item_id'];
            $item_name = $row['item_name'];
            $item_price = $row['price'];
            $_SESSION['item_id'] = $item_id;
            $_SESSION['item_name'] = $item_name;
            $_SESSION['item_price'] = $item_price;
    ?>
    
    <section class="container" id="itemOrder">
        <div class="box" id="itemPic">
            <img src="images/item2_display.jpg" alt="Malaysia">
        </div>
        <div class="box" id="itemInfo">
            <div class="row" id="itemName">
                <h2><?php echo $_SESSION['item_name']; ?></h2>
            </div>
            
            <?php
                if(isset($_REQUEST['pplNum'])){
                    $pplNum = $_REQUEST['pplNum'];
                    $dateWant = $_POST['dateWant'];
                    $_SESSION['pplNum'] = $pplNum;
                    $_SESSION['dateWant'] = $dateWant;
                    header("Location: makeOrder.php");
                }
                
            
            ?>
            
            
            
            
            <form name="order" action="" method="POST">
                <div class="row input-group" >
                <br>
                <label>Price    </label>
                <h2 id="price"></h2>
                <label for="pplNum">Amount of People</label><br>
                <input  min="1" max="20" type="number" name="pplNum" id="pplNum" value="1"   onchange="cal_total()" required/>
                </div>
                <div class="row input-group">
                    <br>
                    <label for="dateWant">Travel Date</label><br>
                    <input type="date" name="dateWant" required/>
                </div>
                <div class="row input-group">
                    <input type="submit" name="order" value="Buy Now" />
                </div>
            </form>
            <?php
                echo "
                <script>
                    function cal_total(){
                        var pplNum = document.getElementById('pplNum').value;

                        var unit_price = $item_price;
                        var total = pplNum * unit_price;
                        var result = 'BND'+ '   ' + total;
                        document.getElementById('price').innerHTML=result;
                        
                    }
                    cal_total();
                </script>
                "
            ?>
            
        </div>
        <div class="box" id="itemDetails">
            <h4>Details</h4>
            <ul>
                <li>Visit Badu Cave and Dark Cave, to experience the pure darkness</li>
                <li>Shopping in Pavilion and visit the Twin Tower</li>
                <li>Taste the true Malay local food</li>
            </ul>
        </div>
    </section>
    
    <?php } ?>
    
    
    
    
	<?php include("footer.php"); ?>
    

</body>
</html>