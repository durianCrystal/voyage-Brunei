<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>
    <link rel="stylesheet" href="css/account.css"/>
    <link rel="stylesheet" href="css/orderTabs.css"/>

    <style>
        #profile{
            background: burlywood;
        }
    </style>
</head>
    
<body >
    
    <?php include('navBar.php'); ?>
    
    <?php 
        require('db.php');
        $user_name = $_SESSION['user_name'];
        $query = "SELECT * FROM users WHERE user_name = '$user_name'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            $profile_pic = $row['profile_pic'];
            $email = $row['email'];
            $b_date = $row['b_date'];
            $create_time = $row['create_time'];
            $_SESSION['profile_pic'] = $profile_pic;
            $_SESSION['email'] = $email;
            $_SESSION['b_date'] = $b_date;
            $_SESSION['create_time'] = $create_time;
        }else{
            echo "<h2>Profile pic can't find</h2>";
        }
        
        ?>
    
    <section id="body">
        <aside id="sidebar" class="column-left">
			
            
            <div id="profilePic">
                <img src="<?php echo $_SESSION['profile_pic']; ?>" > <br>
            </div>
            <div id="username">
                <p><?php echo $_SESSION['user_name']; ?></p>
            </div>
			
            <div id="tabs">
                <div class="tab" id="profile">
                    <a href=account.php> <h3>Profile</h3></a>
                </div>
                <div class="tab" id="myOrder">
                    <h3 style=" background: lightblue; color: white;">My Order</h3>
                </div>
                <div class="tab" id="inbox">
                    <a href=inbox.php><h3>Inbox</h3></a>
                </div>
            </div>
			
			


						
        </aside>
        
       
        
        <section id="content" class="column-right">
            <div class="row" id="tab_title">
                <h1>My Order</h1>
            </div>
             <?php
            //to display orders in pages
            $page = @$_GET["page"];
            if($page == "" || $page == "1"){
                $page1=0;
            } 
            else{
                $page1 = ($page*3)-3;
            }
            $user_id = $_SESSION['user_id'];
            $query_order = mysqli_query($con, "SELECT * FROM orders WHERE user_id = '$user_id' limit $page1, 3");
            while($row=mysqli_fetch_array($query_order)){
                //display order infomation
                ?>
                <div class='orderTab'>
                    <div class='header'>
                        <div class="col1">
                            <label>Order ID</label>
                        <p><?php echo $row['order_id'];?> </p>
                        </div>
                        <div class="col2">
                            <label>Status</label>
                            <p><?php echo $row['status'];?> </p>
                        </div>
                        
                    </div>
                    <div id="orderName">
                            <h3><?php echo $row['item_name'];?></h3>
                    </div>
                    <div class="tabDetails">
                        
                        <div class="col1" id="orderPrice">
                            <label>Total</label>
                            <h3><?php echo $row['total'];?></h3>
                            
                        </div>
                        <div class="col2" id="travelDate">
                            <label>Date</label>
                            <h3><?php echo $row['start_time'];?></h3>

                            
                        </div>
                        
                        
                        
                    </div>
                </div>
                
                <?php
            }
        
            //to count the number of pages
            $query_all_order = mysqli_query($con, "SELECT * FROM orders WHERE user_id = '$user_id'");
            $count = mysqli_num_rows($query_all_order);
            $a = $count / 3;
            $a = ceil($a);
            
            if($page == "" || $page == "1"){
                $b = 1;
                $next = $b + 1;
                if($count > 3){
                ?>
                
                    <a href="myOrder.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                
                 <?php }
            }
            else if($page == $a){
                $b = $page;
                $previous = $b - 1;
                ?>
                
                <a href="myOrder.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a> <?php
            }
            else{
                $b = $page;
                $previous = $b - 1;
                $next = $b + 1;
                ?>
                
                 
                <a href="myOrder.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                <a href="myOrder.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a>
            
            <?php
            }
            /*for($b = 1; $b <= $a; $b++){
                ?>
                <a href="myOrder.php?page=<?php echo $b;?>"><?php echo $b; ?></a> <?php
            }*/
        ?>
            
		</section>


	</section>

    
    <style>
        .round a {
            text-decoration: none;
            display: inline-block;
            #padding: 8px 16px;
        }

        .round a:hover {
            background-color: #ddd;
            color: black;
        }

        .previous {
            background-color: #f1f1f1;
            color: black;
        }

        .next {
            background-color: #55d6aa;
            color: white;
        }

        .round {
            #border-radius: 50%;
            padding: 10px 15px;
            float: right;
            margin-top: 10px;
        }
    </style>
    
    <?php include("footer.php"); ?>
    
	
    

</body>
</html>