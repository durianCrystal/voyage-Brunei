<!DOCTYPE html>
<html>
<head><title>Login</title>
    <link rel="stylesheet" href="css/Style.css"/>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
</head>
<body>
    
    <?php include("admin_navBar.php"); ?>
    
<?php
require('db.php');

if(isset($_POST['admin_name'])){
	$admin_name = stripslashes($_REQUEST['admin_name']);
	$admin_name = mysqli_real_escape_string($con, $admin_name);
	
	$admin_password = stripslashes($_REQUEST['admin_password']);
	$admin_password = mysqli_real_escape_string($con, $admin_password);

	$query = "SELECT * FROM admin WHERE admin_name = '$admin_name' and admin_password=
	'".md5($admin_password)."'";
	
	$result = mysqli_query($con, $query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
	$row = mysqli_fetch_assoc($result);
	if($rows==1){
		$_SESSION['admin_name']=$admin_name;
        $_SESSION['admin_id']=$row['admin_id'];
		header("Location: admin_index.php");
	}else{
		echo "
        <div class='header'>
	    <h2>Oops!</h2>
        </div>
        <div class='form'>
		<h3>username/password is incorrect.</h3>
		<br/>Click here to <a href='login.php'>Login</a></div>";
	}
}else{
?>
<div class="header">
	<h2>Admin Login</h2>
</div>
<div class="form">
	<form name="login" action="" method="POST">
		<div class="input-group">
			<input type="text" name="admin_name" placeholder="Username" required />
		</div>
		<div class="input-group">
			<input type="password" name="admin_password" placeholder="Password" required />
		</div>
		<div class="input-group">
			<input type="submit" name="submit" value="Log in" />
		</div>

	</form>

</div>
<?php } ?>
    
</body>
</html>