/********Active Account**********/
customer
	username: crystal
	password: 19980523
admin
	adminname: admin
	password: 12345

/********Notice******************/
1. The search box in the index is not activated due to not enough items.
2. customer system entrance - index.php
3. admin system entrance - admin_index.php / admin_login.php
