<!DOCTYPE html>
<html>
<head><title>Registration</title>
    <link rel="stylesheet" href="css/Style.css"/>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
</head>
<body>
    
<?php include('navBar.php'); ?>
    
<?php
require('db.php');
if(isset($_REQUEST['user_name'])){
		
	
	$user_name = stripslashes($_REQUEST['user_name']);
	$user_name = mysqli_real_escape_string($con, $user_name);
	
	$user_password = stripslashes($_REQUEST['user_password']);
	$user_password = mysqli_real_escape_string($con, $user_password);
	
	$email = stripslashes($_REQUEST['email']);
	$email = mysqli_real_escape_string($con, $email);
	
    $b_date = stripslashes($_REQUEST['b_date']);
    
    $country = stripslashes($_REQUEST['country']);
    $country = mysqli_real_escape_string($con, $country);
    
	$create_time = date("Y-m-d H:i:s");
	
	$query = "INSERT into users (user_name, user_password, email, b_date, country, create_time)
	VALUES('$user_name','".md5($user_password)."','$email','$b_date','$country','$create_time')";
		
	$result = mysqli_query($con, $query);
    
    //to avoid the same user name
	$query_name = "SELECT * FROM users WHERE user_name = '$user_name'";
    $result_name = mysqli_query($con, $query_name) or die(mysql_error());
    $rows_name = mysqli_num_rows($result_name);
    $result = $result && ($rows_name == 0);
    
	if($result){
		echo "<div class='header'><h2>Regsitration completed</h2></div>
		<div class='form'><h3>You are registered successfully</h3>
		<br/>Click here to <a href='login.php'>Login</a></div>";
		
	}
    if ($rows_name > 0){
        echo "<div class='header'><h2>Oops</h2></div>
		<div class='form'><h3>The username has been used!</h3>
		<br/>Click here to <a href='registration.php'>register again</a></div>";
    }
	
}else{
?>
<div class="header">
	<h2>Registration</h2>
</div>
<div class="form">
	<form name="registration" action="" method="POST">
		<div class="input-group">
            <label>Username</label>
			<input type="text" name="user_name" id="user_name"  required />
            <label id="username_alert"></label>
		</div><br>
		<div class="input-group">
            <label>Password</label>
			<input type="password" name="user_password" required />
		</div><br>
		<div class="input-group">
            <label>Email</label>
			<input type="email" name="email" placeholder="e.g. Example@email.com " required />
		</div><br>
        <div class="input-group">
            <label>Birthday</label>
			<input type="date" name="b_date" required />
		</div><br>
        <div class="input-group">
            <label>Country</label>
			<input type="text" name="country" placeholder="E.g. Brunei" required />
		</div><br>
		<div class="input-group">
			<input type="submit" name="submit" value="Register" />
		</div>

	</form>
</div>
<style>
    label{
        color: darkslategrey;
        display: block;
    }
    
</style>



<?php } ?>
    
<?php include("footer.php"); ?>
</body>
</html>