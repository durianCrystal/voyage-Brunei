<header>
    <div class="container navbar">
        <img class="logo" src="images/logo.png">
      

        <nav>
        <ul>
          <li><a href="admin_index.php">Home</a></li>
  
            <?php
                session_start();
                if(isset($_SESSION['admin_name'])):?>

                <li> <a href="admin_inbox.php">Inbox</a></li>
               <?php

                else:?>

                <li><a href="admin_login.php">Inbox</a></li>
                <?php
                endif;

            ?>
            <?php
                if(isset($_SESSION['admin_name'])):?>

                <li> <a href="admin_orders.php">Orders</a></li>
               <?php

                else:?>

                <li><a href="admin_login.php">Orders</a></li>
                <?php
                endif;

            ?>
          <?php
                if(isset($_SESSION['admin_name'])):?>

                <li> <a href="admin_logout.php">Logout</a></li>
               <?php

                else:?>

                <li><a href="admin_login.php">Login</a></li>
                <?php
                endif;

            ?>
        </ul>
        </nav>
    </div>
</header> 
