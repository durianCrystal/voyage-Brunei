<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>
    <link rel="stylesheet" href="css/account.css"/>
    <style>
        #profile{
            background: burlywood;
        }
    </style>
</head>
    
<body >
    
    <?php include('admin_navBar.php'); ?>
    <?php
        if(!isset($_SESSION['admin_name'])){
            header("Location: admin_login.php");
            exit();
        }
    ?>
    <?php 
        require('db.php');
        $admin_name = $_SESSION['admin_name'];
        $query = "SELECT * FROM admin WHERE admin_name = '$admin_name'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            $_SESSION['admin_id'] = $row['admin_id'];
            
        }else{
            echo "<h2></h2>";
        }
        
        ?>
    
    <section id="body">
        <aside id="sidebar" class="column-left">
			
			<h2>Admin Management System</h2>
            <div id="tabs">
                <div class="tab" id="Orders">
                    <a href="admin_orders.php"><h3>Orders</h3></a>
                </div>

                <div class="subtab" id="all_orders">
                    <a href=admin_orders.php><h3>All Orders</h3></a>
                </div>
                <div class="subtab" id="submitted">
                    <a href=admin_orders_submitted.php><h3>Submitted</h3></a>
                </div>
                <div class="subtab" id="confirmed">
                    <a href=admin_orders_confirmed.php><h3>Confirmed</h3></a>
                </div>
                <div class="subtab" id="done">
                    <a href=admin_orders_done.php><h3>Done</h3></a>
                </div>
                <div class="subtab" id="cancelled">
                    <a href=admin_orders_cancelled.php><h3>Cancelled</h3></a>
                </div>

                <div class="tab" id="Inbox">
                    <a href=admin_orders.php><h3>Inbox</h3></a>
                </div>
            </div>
			
			


						
        </aside>
        
        <section id="content" class="column-right">
            <div class="row" id="tab_title">
                <h1></h1>
            </div>

		</section>


	</section>

    <style>
        #sidebar h2{
            color:darkslategrey;
            margin: 20px 0;
            font-family: "Lato", Arial, sans-serif;
            font-weight: 200;
            font-size: 25px;
        }
        
        #sidebar #tabs{
            text-align: right;
        }
        #sidebar .tab h3{
            padding-right: 20px;
        }
        #sidebar .subtab h3{
            padding-right: 20px;
        }
        section#content {
            width: 70%;
        }
        aside#sidebar {
            width:19%;


        }

    </style>
    
    
    
    
    
    
	<?php include("footer.php"); ?>
    

</body>
</html>