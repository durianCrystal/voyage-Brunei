<!DOCTYPE html>
<html>
<head><title>Login</title>
    <link rel="stylesheet" href="css/Style.css"/>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
</head>
<body>
    
    <?php include("navBar.php"); ?>
    
<?php
require('db.php');

if(isset($_POST['user_name'])){
	$user_name = stripslashes($_REQUEST['user_name']);
	$user_name = mysqli_real_escape_string($con, $user_name);
	
	$user_password = stripslashes($_REQUEST['user_password']);
	$user_password = mysqli_real_escape_string($con, $user_password);

	$query = "SELECT * FROM users WHERE user_name = '$user_name' and user_password=
	'".md5($user_password)."'";
	
	$result = mysqli_query($con, $query) or die(mysql_error());
	$rows = mysqli_num_rows($result);
	$row = mysqli_fetch_assoc($result);
	if($rows==1){
		$_SESSION['user_name']=$user_name;
        $_SESSION['user_id']=$row['user_id'];
		header("Location: index.php");
	}else{
		echo "
        <div class='header'>
	    <h2>Oops!</h2>
        </div>
        <div class='form'>
		<h3>username/password is incorrect.</h3>
		<br/>Click here to <a href='login.php'>Login</a></div>";
	}
}else{
?>
<div class="header">
	<h2>Login</h2>
</div>
<div class="form">
	<form name="login" action="" method="POST">
		<div class="input-group">
			<input type="text" name="user_name" placeholder="Username" required />
		</div>
		<div class="input-group">
			<input type="password" name="user_password" placeholder="Password" required />
		</div>
		<div class="input-group">
			<input type="submit" name="submit" value="Log in" />
		</div>

	</form>
	<p>Not registered yet? <a href="registration.php">Register Here</a></p>
</div>
<?php } ?>
    
<?php include("footer.php"); ?>
</body>
</html>