<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <script>
        MyBanners = new Array('images/banner1.jpg', 'images/banner2.jpg', 'images/banner3.jpg');
        banner = 0;
        function ShowBanners(){
            if(document.images){
                banner++;
                if(banner == MyBanners.length){
                    banner = 0;
                }
                document.ChangeBanner.src=MyBanners[banner];
                setTimeout("ShowBanners()", 2000);
            }
        }

    </script>
</head>
    
<body onload="ShowBanners()">
    
    <?php include("navBar.php");?>
    <?php 
        //direct to the search result
    ?>
    
    <section id="banner">
        <div id="sliderDiv">
            <br>
            <img src="images/banner1.jpg" name = "ChangeBanner" id="slider"/>
        </div>
        
        <div id="overlay"></div>
        
        <div id="searchBox">
        <form action="" method="POST">
            <div class="input-group">
                <br>
                <label for="destination">Destination</label><br>
                <select name="#" class="input-group" id="destination">
                    <option value="Brunei">Brunei</option>
                    <option value="Malaysia">Malaysia</option>
                    <option value="China">China</option>
                </select>
            </div>
            <div class="input-group">
                <br>
                <label for="dateWant">Travel Date</label><br>
                <input type="date" name="dateWant" />
            </div>
            <div class="input-group">
                <input type="submit" name="submit" value="Search" />
            </div>
        </form>
        </div>
        
        
    </section>
    
    <section id="boxes">
        
        <div class="description">
            <h2>Popular Destination</h2>
            <p>Various types of trip schedules are available now!</p>
        </div>
        <div class="container">
            <div class="box">
					<a href="item_1.php" class="card">
						<figure>
							<img src="images/country1.jpg" alt="Image">
						</figure>
						<div class="text">
							<h2>Brunei</h2>
							<p></p>
						</div>
					</a>
				</div>
				<div class="box">
					<a href="item_2.php" class="card">
						<figure>
							<img src="images/country2.jpg" alt="Image">
						</figure>
						<div class="text">
							<h2>Malaysia</h2>
							<p></p>
						</div>
					</a>
				</div>
				<div class="box">
					<a href="item_3.php" class="card">
						<figure>
							<img src="images/country3.jpg" alt="Image">
						</figure>
						<div class="text">
							<h2>China</h2>
							<p></p>
						</div>
					</a>
				</div>
            </div>
    </section>
        
	<?php include("footer.php"); ?>
    

</body>
</html>