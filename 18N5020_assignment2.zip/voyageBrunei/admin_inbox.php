<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>
    <link rel="stylesheet" href="css/account.css"/>
    <link rel="stylesheet" href="css/orderTable.css"/>
    <link rel="stylesheet" href="css/more.css"/>
    <style>
        #profile{
            background: burlywood;
        }
    </style>
</head>
    
<body >
    
    <?php include('admin_navBar.php'); ?>
    <?php
        if(!isset($_SESSION['admin_name'])){
            header("Location: admin_login.php");
            exit();
        }
    ?>
    <?php 
        require('db.php');
        $admin_name = $_SESSION['admin_name'];
        $query = "SELECT * FROM admin WHERE admin_name = '$admin_name'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            $_SESSION['admin_id'] = $row['admin_id'];
            
        }else{
            echo "<h2></h2>";
        }
        
        ?>
    <div id="bg"></div>
    <section id="body">
        <aside id="sidebar" class="column-left">
			
			<h2>Admin Management System</h2>
            <div id="tabs">
                <div class="tab" id="Orders">
                    <a href="admin_orders.php"><h3>Orders</h3></a>
                </div>

                <div class="subtab" id="all_orders">
                    <a href=admin_orders.php><h3>All Orders</h3></a>
                </div>
                <div class="subtab" id="submitted">
                    <a href=admin_orders_submitted.php><h3>Submitted</h3></a>
                </div>
                <div class="subtab" id="confirmed">
                    <a href=admin_orders_confirmed.php><h3>Confirmed</h3></a>
                </div>
                <div class="subtab" id="done">
                    <a href=admin_orders_done.php><h3>Done</h3></a>
                </div>
                <div class="subtab" id="cancelled">
                    <a href=admin_orders_cancelled.php><h3>Cancelled</h3></a>
                </div>

                <div class="tab" id="Inbox">
                    <a href=admin_orders.php><h3 style=" background: lightblue; color: white;">Inbox</h3></a>
                </div>
            </div>
			
			


						
        </aside>
        
        <section id="content" class="column-right">
            <div class="row" id="tab_title">
                <h1>Inbox</h1>
            </div>
         <div class="container">
            
            <table class="responsive-table">
            <thead>
              <tr>
                  <th scope="col">sent_time</th>
                  <th scope="col">user id</th>
                  <th scope="col">user name</th>
                  <th scope="col">message</th>
                  <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
            <?php
                //setting paging inside this .php
                $page = @$_GET["page"];
                if($page == "" || $page == "1"){
                    $page1=0;
                } 
                else{
                    $page1 = ($page*5)-5;
                }
                
                $query_order = mysqli_query($con, "SELECT * FROM admin_inbox ORDER BY is_read ASC, sent_time DESC limit $page1, 5");
                $this_row = 0;  //to mark down the current row 
                while($row=mysqli_fetch_array($query_order)){
                //display order infomation
                    
                    //get username
                    $user_id = $row['user_id'];
                    $query_username = "SELECT * FROM users WHERE user_id = '$user_id'";
                    $result_username =  mysqli_query($con, $query_username);
                    $row_user=mysqli_fetch_array($result_username);
                    $user_name = $row_user['user_name'];
                    // to set the read message grey
                    if($row['is_read']==1){
                        $style = "background-color: rgba(94, 93, 82, 0.1)";
                    }else{
                        $style = "background-color:white";
                    }
                    
                ?>
                    <tr  style="<?php echo $style; ?>"  >
                        <td data-title="time"><?php echo $row['sent_time']; ?></td>
                        <th data-title="user id"><?php echo $row['user_id']; ?></th>
                        <td data-title="username"><?php echo $user_name; ?></td>
                        <td data-title="message"><?php echo $row['message']; ?></td>
                        <td data-title="reply"><button id="more_btn" onclick="expand_details(<?php echo $this_row; ?>)">Reply</button></td>
                        
                    </tr>
                    
                    <div class="hidden_more" id="hidden_more_<?php echo $this_row; ?>" style="display:none">
                        <h3>Message</h3>
                        <div class="input-group">
                            <div class="customer_message">
                            <label><?php echo $user_name; ?>:    </label>
                            <p><?php echo $row['message']; ?></p>
                            </div>
                        </div>
                        
                        <form action="" method="POST">
                            
                            <div class="admin_reply input-group">
                                <textarea id="message" class="text" cols="65" rows ="20" name="admin_message"></textarea>
                            </div>
                            <div class="detail_row input-group">
                                <input type="submit" name="submit<?php echo $row['m_id']; ?>" value="Submit" />
                                <button onclick="hidediv(<?php echo $this_row; ?>)">Exit</button>
                            </div>
                        </form>
                        
                        <?php
                            //pass the message to user inbox
                            $btn_name = 'submit'.(string)$row['m_id'];
                            if(isset($_POST[$btn_name])){
                                $user_id = $row['user_id'];
                                $admin_message = $_POST['admin_message'];
                                $m_id = $row['m_id'];
                                
                                //to avoid submitting the messages that have been submitted before
                                /*
                                $dup = $_REQUEST['admin_message'];
                                $values = explode(' ', $dup);
                                $count_reply = count($values);
                                if($count_reply>1){
                                    //if the message has been replied once
                                    $admin_message = $_REQUEST['admin_message'][$count_reply];
                                    $query_admin = "INSERT INTO user_inbox (user_id, message)
                                    VALUES('$user_id', '$admin_message')";
                                }else{
                                    
                                    
                                    
                                }*/
                                $query_admin = "INSERT INTO user_inbox (user_id, message)
                                    VALUES('$user_id', '$admin_message')";
                                $result_admin = mysqli_query($con, $query_admin);
                                if($result_admin){
                                    $update = mysqli_query($con, "UPDATE admin_inbox
                                    SET is_read = 1
                                    WHERE m_id = $m_id");
                                    
                                }
                                
                            }
                        ?>
                        
                    </div>
                <?php
                $this_row = $this_row + 1;
            }
                ?>
                </tbody>
                </table> 
            </div> 
            
                <?php
                //to count the number of pages
            $query_all_order = mysqli_query($con, "SELECT * FROM admin_inbox ");
            $count = mysqli_num_rows($query_all_order);
            $a = $count / 5;
            $a = ceil($a);
            
            if($page == "" || $page == "1"){
                $b = 1;
                $next = $b + 1;
                if($count > 5){
                ?>
                
                    <a href="admin_orders.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                
                 <?php }
            }
            else if($page == $a){
                $b = $page;
                $previous = $b - 1;
                ?>
                
                <a href="admin_orders.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a> <?php
            }
            else{
                $b = $page;
                $previous = $b - 1;
                $next = $b + 1;
                ?>
                
                 
                <a href="admin_orders.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                <a href="admin_orders.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a>
            
            <?php
            }
            ?>
               
         
                
  

    

		</section>


	</section>
    <script>
        
        function expand_details(this_row){
            showdiv(this_row)
        }
        function showdiv(this_row) {            
            document.getElementById("bg").style.display ="block";
            document.getElementsByClassName("hidden_more")[this_row].style.display ="block";
        }
        function hidediv(this_row) {
            document.getElementById("bg").style.display ='none';
            document.getElementsByClassName("hidden_more")[this_row].style.display ='none';
        }
    </script>

    <style>
        #sidebar h2{
            color:darkslategrey;
            margin: 20px 0;
            font-family: "Lato", Arial, sans-serif;
            font-weight: 200;
            font-size: 25px;
        }
        
        #sidebar #tabs{
            text-align: right;
        }
        #sidebar .tab h3{
            padding-right: 20px;
        }
        #sidebar .subtab h3{
            padding-right: 20px;
        }
        section#content {
            width: 70%;
        }
        aside#sidebar {
            width:19%;


        }
        
        
        .round a {
            text-decoration: none;
            display: inline-block;
            #padding: 8px 16px;
        }

        .round a:hover {
            background-color: #ddd;
            color: black;
        }

        .previous {
            background-color: #f1f1f1;
            color: black;
        }

        .next {
            background-color: #55d6aa;
            color: white;
        }

        .round {
            #border-radius: 50%;
            padding: 10px 15px;
            float: right;
            margin-top: 10px;
        }
        
        .customer_message{
            background-color: lightgrey;
            width: 425px;
            height: auto;
            padding: 5px;
            text-align: left;
            margin-bottom: 20px;
            -webkit-box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.08);
            -moz-box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.08);
            -ms-box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.08);
            -o-box-shadow: 0px 2px 5px 0px rgba(0, 0, 0, 0.08);
            box-shadow: 0px 2px 5px 0px rgba(0,0,0,0.08);
            -webkit-border-radius: 0px;
            -moz-border-radius: 0px;
            -ms-border-radius: 0px;
            border-radius: 0px;
            -webkit-transition: 0.3s;
            -o-transition: 0.3s;
            transition: 0.3s;
            
        }
        
        .customer_message p{
            margin-bottom: 0;
            margin-top: 5px;
            
        }
        
        .admin_reply{
            
        }
        
        .hidden_more{
            height: 85%;
            text-align: center;
        }
        
        .hidden_more .input-group{
            text-align: center;
            display: inline-block;
        }
        
        .hidden_more input[type='submit']{
            width: 100px;
        }
        .hidden_more button{
            width: 100px;
        }
        
        table{
            width: 100%;
        }

    </style>
    
    
    
    
    
    
	<?php include("footer.php"); ?>
    

</body>
</html>