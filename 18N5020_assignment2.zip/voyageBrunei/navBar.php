<header>
    <div class="container navbar">
        <img class="logo" src="images/logo.png">
      

        <nav>
        <ul>
          <li><a href="index.php">Home</a></li>
  
            <?php
                session_start();
                if(isset($_SESSION['user_name'])):?>

                <li> <a href="inbox.php">Inbox</a></li>
               <?php

                else:?>

                <li><a href="login.php">Inbox</a></li>
                <?php
                endif;

            ?>
            <?php
                if(isset($_SESSION['user_name'])):?>

                <li> <a href="account.php">Account</a></li>
               <?php

                else:?>

                <li><a href="login.php">Account</a></li>
                <?php
                endif;

            ?>
          <?php
                if(isset($_SESSION['user_name'])):?>

                <li> <a href="logout.php">Logout</a></li>
               <?php

                else:?>

                <li><a href="login.php">Login</a></li>
                <?php
                endif;

            ?>
        </ul>
        </nav>
    </div>
</header> 
