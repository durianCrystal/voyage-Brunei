<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>
    <link rel="stylesheet" href="css/account.css"/>
    <style>
        #profile{
            background: burlywood;
        }
    </style>
</head>
    
<body >
    
    <?php include('navBar.php'); ?>
    
    <?php 
        require('db.php');
        $user_name = $_SESSION['user_name'];
        $query = "SELECT * FROM users WHERE user_name = '$user_name'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            $profile_pic = $row['profile_pic'];
            $email = $row['email'];
            $b_date = $row['b_date'];
            $create_time = $row['create_time'];
            $_SESSION['profile_pic'] = $profile_pic;
            $_SESSION['email'] = $email;
            $_SESSION['b_date'] = $b_date;
            $_SESSION['create_time'] = $create_time;
        }else{
            echo "<h2>Profile pic can't find</h2>";
        }
        
        ?>
    
    <section id="body">
        <aside id="sidebar" class="column-left">
			
            
            <div id="profilePic">
                <img src="<?php echo $_SESSION['profile_pic']; ?>" > <br>
            </div>
            <div id="username">
                <p><?php echo $_SESSION['user_name']; ?></p>
            </div>
			
            <div id="tabs">
                <div class="tab" id="profile">
                    <h3 style=" background: lightblue; color: white;">Profile</h3>
                </div>
                <div class="tab" id="myOrder">
                    <a href=myOrder.php><h3>My Order</h3></a>
                </div>
                <div class="tab" id="inbox">
                    <a href=inbox.php><h3>Inbox</h3></a>
                </div>
            </div>
			
			


						
        </aside>
        
        <section id="content" class="column-right">
            <div class="row" id="tab_title">
                <h1>My Profile</h1>
            </div>
            <div class="row profile_display">
                <label>Email  </label>
                <p><?php echo $_SESSION['email']; ?></p>
            </div>
            <div class="row profile_display">
                <label>Birthday  </label>
                <p><?php echo $_SESSION['b_date']; ?></p>
            </div>
            <div class="row profile_display">
                <label>Create Time  </label>
                <p><?php echo $_SESSION['create_time']; ?></p>
            </div>
		</section>


	</section>

    
    
    
    
    
	<?php include("footer.php"); ?>
    

</body>
</html>