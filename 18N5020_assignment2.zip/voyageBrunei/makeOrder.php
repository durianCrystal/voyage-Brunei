<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/Style.css"/>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/index.css"/>
</head>
<body>
    
<?php include('navBar.php'); ?>
    
<?php 
    if(!isset($_SESSION['user_name'])){
        header("Location: login.php");
        exit();
    }
?>
<?php

require('db.php');
if(isset($_REQUEST['tel_num'])){
    $user_id = $_SESSION['user_id'];
	$item_id = $_SESSION['item_id'];
    $item_name = $_SESSION['item_name'];     
    $ppl_num = $_SESSION['pplNum'];
    $start_time = $_SESSION['dateWant'];
    $end_time = $_SESSION['dateWant'];
	$total = $_SESSION['item_price'] * $_SESSION['pplNum'];
    $tel_num = $_POST['tel_num'];
    
	$submit_time = date("Y-m-d H:i:s");
    $update_time = $submit_time;
	
	$query = "INSERT into orders (user_id, item_id, item_name, ppl_num, start_time, end_time, total, tel_num, submit_time, update_time)
	VALUES('$user_id','$item_id','$item_name','$ppl_num','$start_time', '$end_time', '$total', '$tel_num', '$submit_time', '$update_time')";
	
	//echo $query;
	
	$result = mysqli_query($con, $query);
	
	if($result){
        
		echo "<div class='header'><h2>Make Order</h2></div>
		<div class='form'><h3>You have submitted you order successfully. Your order will be processed in 24h. </h3>
		<br/>Click here to <a href='myOrder.php'>check the details.</a></div>";
		
	}
	
}else{
?>
<div class="header">
	<h2>Make Order</h2>
</div>
    
<div class="form">
	<form name="order" action="" method="POST">
		<div class="input-group">
            <br><label>Telephone</label><br>
			<input type="text" name="tel_num" placeholder="e.g. +86-12345678" required />
		</div>
		<div class="input-group">
            <br><label>Amount of People</label><br>
			<input  min="1" max="20" type="number" name="pplNum" id="pplNum" value="<?php echo $_SESSION['pplNum']; ?>" onchange="cal_total()" required/>
		</div>
        <div class="input-group">
            <br><label>Travel Date</label><br>
			<input type="date" name="dateWant" value="<?php echo $_SESSION['dateWant']; ?>" required/>
		</div>
        <div class="input-group">
        <br>
            <label>Price    </label>
            <h2 id="price"></h2>
        </div>
		<div class="input-group">
			<input type="submit" name="submit" value="Submit" />
		</div>

	</form>
    
    <style>
        label{
            color: darkslategray;
        }
    </style>
    
    <?php
        $item_price = $_SESSION["item_price"];
        echo "
                <script>
                    function cal_total(){
                        var pplNum = document.getElementById('pplNum').value;

                        var unit_price = $item_price;
                        var total = pplNum * unit_price;
                        var result = 'BND'+ '   ' + total;
                        document.getElementById('price').innerHTML=result;
                        
                    }
                    cal_total();
                </script>
                "
                
    ?>
    
</div>
<?php } ?>
    
<?php include("footer.php"); ?>
	
    
</body>
</html>