<!DOCTYPE html>
<html>
<head><title>Voyage Brunei - Your Best Trip Planner</title>
    <link rel="stylesheet" href="css/naviBar.css"/>
    <link rel="stylesheet" href="css/index.css"/>
    <link rel="stylesheet" href="css/footer.css"/>
    <link rel="stylesheet" href="css/input.css"/>
    <link rel="stylesheet" href="css/items.css"/>
    <link rel="stylesheet" href="css/account.css"/>
    <link rel="stylesheet" href="css/orderTable.css"/>
    <link rel="stylesheet" href="css/more.css"/>

    <style>
        #profile{
            background: burlywood;
        }
    </style>
</head>
    
<body >
    
    <?php include('admin_navBar.php'); ?>
    <?php
        if(!isset($_SESSION['admin_name'])){
            header("Location: admin_login.php");
            exit();
        }
    ?>
    <?php 
        require('db.php');
        $admin_name = $_SESSION['admin_name'];
        $query = "SELECT * FROM admin WHERE admin_name = '$admin_name'";
        $result = mysqli_query($con, $query) or die(mysql_error());
        $rows = mysqli_num_rows($result);
        if($rows == 1){
            $row = mysqli_fetch_assoc($result);
            
        }else{
            echo "<h2></h2>";
        }
        
        ?>
    <div id="bg"></div>
    <section id="body">
        <aside id="sidebar" class="column-left">
			
			<h2>Admin Management System</h2>
            <div id="tabs">
                <div class="tab" id="Orders">
                    <a ><h3 style=" background: lightblue; color: white;" >Orders</h3></a>
                </div>

                <div class="subtab" id="all_orders">
                    <a href=admin_orders.php><h3>All Orders</h3></a>
                </div>
                <div class="subtab" id="submitted">
                    <a href=admin_orders_submitted.php><h3>Submitted</h3></a>
                </div>
                <div class="subtab" id="confirmed">
                    <a href=admin_orders_confirmed.php><h3>Confirmed</h3></a>
                </div>
                <div class="subtab" id="done">
                    <a href=admin_orders_done.php><h3 style="background: lemonchiffon ; ">Done</h3></a>
                </div>
                <div class="subtab" id="cancelled">
                    <a href=admin_orders_cancelled.php><h3>Cancelled</h3></a>
                </div>

                <div class="tab" id="Inbox">
                    <a href=admin_inbox.php><h3>Inbox</h3></a>
                </div>
            </div>
			
			


						
        </aside>
        
        <section id="content" class="column-right">
            <div class="row" id="tab_title">
                <h1>All Orders</h1>
            </div>
            <div class="container">
            
            <table class="responsive-table">
            <thead>
              <tr>
                  <th scope="col">order id</th>
                  <th scope="col">user id</th>
              <!--    <th scope="col">item id</th>  -->
                  <th scope="col">item name</th>
              <!--    <th scope="col">vehicle</th>
                  <th scope="col">guide</th>  -->
                  <th scope="col">people</th>
                  <th scope="col">start</th>
                  <th scope="col">end</th>
                  <th scope="col">total</th>
              <!--    <th scope="col">Tel</th>
                  <th scope="col">discount</th>
                  <th scope="col">operator</th>
                  <th scope="col">submit</th>
                  <th scope="col">update</th>  -->
                  <th scope="col">status</th>
                  <th scope="col"></th>
              </tr>
            </thead>
            <tbody>
            <?php
                $page = @$_GET["page"];
                if($page == "" || $page == "1"){
                    $page1=0;
                } 
                else{
                    $page1 = ($page*5)-5;
                }
                
                $query_order = mysqli_query($con, "SELECT * FROM orders WHERE status = 'DONE' limit $page1, 5");
                $this_row = 0;  //to mark down the current row 
                while($row=mysqli_fetch_array($query_order)){
                //display order infomation
                    
                    
                ?>
                    <tr>
                        <th scope="row"><?php echo $row['order_id']; ?></th>
                        <td data-title="user_id"><?php echo $row['user_id']; ?></td>
                     <!--   <td data-title="item_id"><?php echo $row['item_id']; ?></td> -->
                        <td data-title="item_name"><?php echo $row['item_name']; ?></td>
                     <!--   <td data-title="v_id"><?php echo $row['v_id']; ?></td>
                        <td data-title="guide_id"><?php echo $row['guide_id']; ?></td>  -->
                        <td data-title="ppl_num"><?php echo $row['ppl_num']; ?></td>
                        <td data-title="start_time"><?php echo $row['start_time']; ?></td>
                        <td data-title="end_time"><?php echo $row['end_time']; ?></td>
                        <td data-title="total" data-type="currency"><?php echo $row['total']; ?></td>
                     <!--   <td data-title="tel_num"><?php echo $row['tel_num']; ?></td>
                        <td data-title="discount"><?php echo $row['discount']; ?></td>
                        <td data-title="operator_id"><?php echo $row['operator_id']; ?></td>
                        <td data-title="submit_time"><?php echo $row['submit_time']; ?></td>
                        <td data-title="update_time"><?php echo $row['update_time']; ?></td> -->
                        <td data-title="status"><?php echo $row['status']; ?></td>
                        <td data-title="more"><button id="more_btn" onclick="expand_details(<?php echo $this_row; ?>)">MORE</button></td>
                        
                    </tr>
                    <div class="hidden_more" id="hidden_more_<?php echo $this_row; ?>" style="display:none">
                        <h3>order details</h3>
                        <div class="detail_row">
                        <label>order id</label>
                        <p><?php echo $row['order_id']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>item id</label>
                        <p><?php echo $row['item_id']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>vehicle id</label>
                        <p><?php echo $row['v_id']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>guide id</label>
                        <p><?php echo $row['guide_id']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>tel</label>
                        <p><?php echo $row['tel_num']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>discount</label>
                        <p><?php echo $row['discount']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>operator</label>
                        <p><?php echo $row['operator_id']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>submit time</label>
                        <p><?php echo $row['submit_time']; ?></p>
                        </div>
                        <div class="detail_row">
                        <label>update time</label>
                        <p><?php echo $row['update_time']; ?></p>
                        </div>
                        <button onclick="hidediv(<?php echo $this_row; ?>)">Exit</button>
                    </div>
                <?php
                $this_row = $this_row + 1;
            }
                ?>
                </tbody>
                </table> 
            </div> 
            
                <?php
                //to count the number of pages
            $query_all_order = mysqli_query($con, "SELECT * FROM orders WHERE status = 'DONE'");
            $count = mysqli_num_rows($query_all_order);
            $a = $count / 5;
            $a = ceil($a);
            
            if($page == "" || $page == "1"){
                $b = 1;
                $next = $b + 1;
                if($count > 5){
                ?>
                
                    <a href="admin_orders.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                
                 <?php }
            }
            else if($page == $a){
                $b = $page;
                $previous = $b - 1;
                ?>
                
                <a href="admin_orders.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a> <?php
            }
            else{
                $b = $page;
                $previous = $b - 1;
                $next = $b + 1;
                ?>
                
                 
                <a href="admin_orders.php?page=<?php echo $next;?>" class="next round"> &#8250;</a>
                <a href="admin_orders.php?page=<?php echo $previous;?>" class="previous round"> &#8249;</a>
            
            <?php
            }
            ?>
               
         
                
  

    

		</section>


	</section>
    <script>
        
        function expand_details(this_row){
            showdiv(this_row)
        }
        function showdiv(this_row) {            
            document.getElementById("bg").style.display ="block";
            document.getElementsByClassName("hidden_more")[this_row].style.display ="block";
        }
        function hidediv(this_row) {
            document.getElementById("bg").style.display ='none';
            document.getElementsByClassName("hidden_more")[this_row].style.display ='none';
        }
    </script>
    <style>
        #sidebar h2{
            color:darkslategrey;
            margin: 20px 0;
            font-family: "Lato", Arial, sans-serif;
            font-weight: 200;
            font-size: 25px;
        }
        #sidebar #tabs{
            text-align: right;
        }
        #sidebar .tab h3{
            padding-right: 20px;
        }
        #sidebar .subtab h3{
            padding-right: 20px;
        }
        section#content {
            width: 70%;
        }
        aside#sidebar {
            width:19%;


        }
        
        .round a {
            text-decoration: none;
            display: inline-block;
            #padding: 8px 16px;
        }

        .round a:hover {
            background-color: #ddd;
            color: black;
        }

        .previous {
            background-color: #f1f1f1;
            color: black;
        }

        .next {
            background-color: #55d6aa;
            color: white;
        }

        .round {
            #border-radius: 50%;
            padding: 10px 15px;
            float: right;
            margin-top: 10px;
        }
        .hidden_more button{
            margin-left: 0;
        }
        .hidden_more{
            height: 70%;
        }
    </style>
    
    
    
    
    
    
	<?php include("footer.php"); ?>
    

</body>
</html>